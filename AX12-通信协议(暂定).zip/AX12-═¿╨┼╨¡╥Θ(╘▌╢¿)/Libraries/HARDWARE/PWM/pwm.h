#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"

#define Reload_Value1 500
#define Reload_Value2 500
#define Reload_Value3 500
#define Reload_Value4 500
#define div 168

void TIM1_PWM_Init(u32 arr,u32 psc);

void Set_pwm1(TIM_TypeDef* TIMx, uint32_t Compare1)	;
void Set_pwm2(TIM_TypeDef* TIMx, uint32_t Compare2);
void Set_pwm3(TIM_TypeDef* TIMx, uint32_t Compare3)	;
void Set_pwm4(TIM_TypeDef* TIMx, uint32_t Compare4);

#endif
