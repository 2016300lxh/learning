#ifndef __LED_H
#define __LED_H
#include "sys.h"



//LED�˿ڶ���
#define LED1 PEout(13)	  // DS1
#define LED2 PEout(14)	// DS2	 
#define LED3 PEout(15)  //DS3

void LED_Init(void);//��ʼ��		 				    
#endif
