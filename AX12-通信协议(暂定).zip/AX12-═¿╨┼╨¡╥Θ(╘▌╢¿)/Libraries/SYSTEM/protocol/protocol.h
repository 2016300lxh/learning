#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#include "stm32f4xx.h"

void analysis_msg(u8 msg[]);
void Message_Display(void);

extern u16 Position[2];
extern u16 Velocity[2];

#define PI 3.141592653589793238462643383279

#endif

