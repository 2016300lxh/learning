#include "stm32f4xx.h"
#include "protocol.h"
#include "LED.h"
#include "AX12.h"
#include "sys.h"
#include "delay.h"
#include "usart.h"

#include "test1.h"

uint8_t id=0x00;
uint8_t idgroup[2] = {0x00,0x01};

u16 Velocity1[2] = {25,250};
u16 Position1[2] = {200,200};


int main()
{
	u8 i = 0,j=0;
	delay_init(168);  //��ʼ����ʱ����
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	LED_Init();

	uart1_init(115200);
	ServoUSART_Init(1000000);

	printf ("Init complete\n");
	
	for(j=0;j<2;j++)
	{		
		while(!pingServo(idgroup[j]))			               //������ɹ�Ping,������ѭ��
		{
			printf ("Ping %d failed\n",idgroup[j]);
			delay_ms(10);
		}
		printf("Ping %d OK\n",idgroup[j]);
    }
	
//	while(!pingServo(id))			               //������ɹ�Ping,������ѭ��
//	{
//		printf ("Ping %d failed\n",idgroup[j]);
//		delay_ms(10);
//	}
	
    while(1) 
	{
		delay_ms(20);
//		LED3=!LED3;
//		delay_ms(250);
//		LED3=!LED3;

		Message_Display();
		
		Test1();
		printf("Pos=%d,%d,%d,%d\r\n",Position[0],Position[1],Velocity[0],Velocity[1]);
		Position[0] = 0;
		Position[1] = 0;
		
//		printf("Position2 = %d\r\n",Position[1]);
//		printf("Velocity1 = %d\r\n",Velocity[0]);
//		printf("Velocity2 = %d\r\n\r\n",Velocity[1]);
		
		
	 }

}
