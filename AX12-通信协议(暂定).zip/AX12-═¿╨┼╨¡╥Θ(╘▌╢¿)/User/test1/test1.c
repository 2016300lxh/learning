#include "test1.h"
#include "AX12.h"
#include "delay.h"
#include "usart.h"
#include "sys.h"
#include "LED.h"
#include "math.h"
#include <string.h>

#include "protocol.h"

extern uint8_t id;
extern uint8_t idgroup[];
extern u16 Position[2];
extern u16 Velocity[2];
extern u16 Position1[2];
extern u16 Velocity1[2];
void Test1()
{	
//    setServoAngle(id,Position[0]);
	Sync_Write_PositionAndVelocity(idgroup,2,(u16*)Position,(u16*)Velocity);	
//    Sync_Write_PositionAndVelocity(idgroup,2,(u16*)Position1,(u16*)Velocity1);
}


