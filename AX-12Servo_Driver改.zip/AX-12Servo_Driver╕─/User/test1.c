#include "test1.h"
#include "AX12.h"
#include "delay.h"
#include "usart.h"
#include "sys.h"
#include "LED.h"

#include "math.h"

extern uint8_t id;
extern uint8_t idgroup[];
extern u16 Position[4];
extern u16 Velocity[4];

void Test1()
{
	u8 freq = 1;
	u8 t=0;
	float temp = 301;
//	temp = Position[0];
//	setServoMaxSpeed(id,0x3ff);
//	while(1)
//	{
//		t=t+1;
//		setServoAngle(id,50*(sin(6.28*freq*t)+0.5));

		setServoAngle(id,(const float)temp);
//		delay_ms(2);
//	}
//	while(1)
//	{
//		t = t + 1;
		
//		Position[0] = 150*(sin(6.28*freq*t)+0.5);
//		Position[1] = 50*(sin(3.14*freq*t)+0.5);
//		Position[2] = 50*(sin(9.42*freq*t)+0.5);
//		Position[3] = 50*(sin(1.57*freq*t)+0.5);
	
//		Sync_Write_PositionAndVelocity(idgroup,4,Position,Velocity);
		delay_ms(1);
//	}
//	Sync_Write_PositionAndVelocity(idgroup,4,Position,Velocity);
	
}


